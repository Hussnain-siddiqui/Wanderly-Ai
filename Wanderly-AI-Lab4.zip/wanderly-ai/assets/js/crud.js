/* Wanderly AI - CRUD + JavaScript control structures lab task */
(function () {
  'use strict';

  // STEP 1: Array of objects. This is the project's main data source.
  let trips = [
    { id: 1, name: 'Istanbul Food Week', destination: 'Istanbul', category: 'Food', duration: 6, budget: 780, difficulty: 'Easy', rating: 4.8 },
    { id: 2, name: 'Lahore Heritage Walk', destination: 'Lahore', category: 'Culture', duration: 3, budget: 420, difficulty: 'Easy', rating: 4.6 },
    { id: 3, name: 'Hunza Mountain Escape', destination: 'Hunza', category: 'Nature', duration: 8, budget: 1250, difficulty: 'Hard', rating: 4.9 },
    { id: 4, name: 'Bali Beach Reset', destination: 'Bali', category: 'Beach', duration: 7, budget: 1680, difficulty: 'Moderate', rating: 4.7 },
    { id: 5, name: 'Dubai Adventure Sprint', destination: 'Dubai', category: 'Adventure', duration: 4, budget: 1450, difficulty: 'Moderate', rating: 4.5 },
    { id: 6, name: 'Kyoto Culture Trail', destination: 'Kyoto', category: 'Culture', duration: 9, budget: 2100, difficulty: 'Moderate', rating: 4.9 }
  ];

  const $ = (id) => document.getElementById(id);
  const grid = $('trip-grid');
  const empty = $('empty-state');

  function escapeHtml(value) {
    return String(value).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  }

  // STEP 2: Read operation — Array.map() creates every card dynamically.
  function renderCards(list = getFilteredTrips()) {
    grid.innerHTML = list.map(trip => `
      <article class="trip-card bg-white border border-slate-200 rounded-2xl overflow-hidden">
        <div class="p-5">
          <div class="flex items-start justify-between gap-3">
            <div>
              <span class="inline-flex px-2.5 py-1 text-xs font-bold rounded-full bg-brand-50 text-brand-700">${escapeHtml(trip.category)}</span>
              <h3 class="mt-3 font-display text-xl font-bold text-slate-900">${escapeHtml(trip.name)}</h3>
              <p class="mt-1 text-sm text-slate-500">📍 ${escapeHtml(trip.destination)}</p>
            </div>
            <span class="text-sm font-bold text-amber-600">★ ${trip.rating.toFixed(1)}</span>
          </div>
          <div class="mt-5 grid grid-cols-3 gap-2 text-center">
            <div class="p-2 bg-slate-50 rounded-lg"><span class="block text-xs text-slate-500">Days</span><strong>${trip.duration}</strong></div>
            <div class="p-2 bg-slate-50 rounded-lg"><span class="block text-xs text-slate-500">Budget</span><strong>$${trip.budget}</strong></div>
            <div class="p-2 bg-slate-50 rounded-lg"><span class="block text-xs text-slate-500">Level</span><strong>${escapeHtml(trip.difficulty)}</strong></div>
          </div>
        </div>
        <div class="flex gap-2 p-4 bg-slate-50 border-t border-slate-200">
          <button data-action="edit" data-id="${trip.id}" class="flex-1 px-4 py-2 rounded-lg bg-white border border-slate-300 font-semibold hover:bg-slate-100">Edit</button>
          <button data-action="delete" data-id="${trip.id}" class="flex-1 px-4 py-2 rounded-lg bg-red-50 text-red-700 border border-red-200 font-semibold hover:bg-red-100">Delete</button>
        </div>
      </article>
    `).join('');

    empty.classList.toggle('hidden', list.length !== 0);
    $('result-count').textContent = `${list.length} of ${trips.length} trip${trips.length === 1 ? '' : 's'} shown`;
    renderStats();
    renderControlStructures();
  }

  function getFilteredTrips() {
    const search = $('search').value.trim().toLowerCase();
    const destination = $('destination-filter').value;
    const category = $('category-filter').value;
    const budget = $('budget-filter').value;
    const duration = $('duration-filter').value;
    const difficulty = $('difficulty-filter').value;

    return trips.filter(trip => {
      const matchesSearch = !search || [trip.name, trip.destination, trip.category, trip.difficulty].some(v => String(v).toLowerCase().includes(search));
      const matchesDestination = destination === 'All' || trip.destination === destination;
      const matchesCategory = category === 'All' || trip.category === category;
      const matchesBudget = budget === 'All'
        || (budget === 'Budget' && trip.budget < 800)
        || (budget === 'Mid' && trip.budget >= 800 && trip.budget <= 1500)
        || (budget === 'Premium' && trip.budget > 1500);
      const matchesDuration = duration === 'All'
        || (duration === 'Short' && trip.duration <= 4)
        || (duration === 'Medium' && trip.duration >= 5 && trip.duration <= 7)
        || (duration === 'Long' && trip.duration >= 8);
      const matchesDifficulty = difficulty === 'All' || trip.difficulty === difficulty;
      return matchesSearch && matchesDestination && matchesCategory && matchesBudget && matchesDuration && matchesDifficulty;
    });
  }

  // STEP 3: Create operation — form submission uses Array.push().
  $('trip-form').addEventListener('submit', function (event) {
    event.preventDefault();
    const form = new FormData(event.target);
    const newTrip = {
      id: Date.now(),
      name: form.get('name').trim(),
      destination: form.get('destination').trim(),
      category: form.get('category'),
      duration: Number(form.get('duration')),
      budget: Number(form.get('budget')),
      difficulty: form.get('difficulty'),
      rating: Number(form.get('rating'))
    };

    if (!newTrip.name || !newTrip.destination || newTrip.duration < 1 || newTrip.budget < 1) {
      showFormMessage('Please enter valid trip details.', false);
      return;
    }

    trips.push(newTrip);
    event.target.reset();
    $('trip-duration').value = 5;
    $('trip-budget').value = 900;
    $('trip-rating').value = 4.5;
    refreshDestinationFilter();
    showFormMessage('Trip added successfully with Array.push().', true);
    renderCards();
  });

  function showFormMessage(message, success) {
    const box = $('form-message');
    box.textContent = message;
    box.className = 'text-sm rounded-lg p-3 ' + (success ? 'bg-green-50 text-green-700' : 'bg-red-50 text-red-700');
  }

  // STEP 4 + 5: Delete uses Array.filter(); Edit opens a pre-filled modal.
  grid.addEventListener('click', function (event) {
    const button = event.target.closest('button[data-action]');
    if (!button) return;
    const id = Number(button.dataset.id);

    if (button.dataset.action === 'delete') {
      trips = trips.filter(trip => trip.id !== id);
      refreshDestinationFilter();
      renderCards();
    } else if (button.dataset.action === 'edit') {
      openEditModal(id);
    }
  });

  function openEditModal(id) {
    const trip = trips.find(item => item.id === id);
    if (!trip) return;
    $('edit-id').value = trip.id;
    $('edit-name').value = trip.name;
    $('edit-destination').value = trip.destination;
    $('edit-category').value = trip.category;
    $('edit-duration').value = trip.duration;
    $('edit-budget').value = trip.budget;
    $('edit-difficulty').value = trip.difficulty;
    $('edit-rating').value = trip.rating;
    $('edit-modal').classList.remove('hidden');
    $('edit-modal').classList.add('flex');
    $('edit-name').focus();
  }

  function closeEditModal() {
    $('edit-modal').classList.add('hidden');
    $('edit-modal').classList.remove('flex');
  }

  $('edit-form').addEventListener('submit', function (event) {
    event.preventDefault();
    const id = Number($('edit-id').value);
    const trip = trips.find(item => item.id === id);
    if (!trip) return;

    trip.name = $('edit-name').value.trim();
    trip.destination = $('edit-destination').value.trim();
    trip.category = $('edit-category').value;
    trip.duration = Number($('edit-duration').value);
    trip.budget = Number($('edit-budget').value);
    trip.difficulty = $('edit-difficulty').value;
    trip.rating = Number($('edit-rating').value);

    closeEditModal();
    refreshDestinationFilter();
    renderCards();
  });

  $('cancel-edit').addEventListener('click', closeEditModal);
  $('close-modal').addEventListener('click', closeEditModal);
  $('edit-modal').addEventListener('click', e => { if (e.target === $('edit-modal')) closeEditModal(); });
  document.addEventListener('keydown', e => { if (e.key === 'Escape') closeEditModal(); });

  // STEP 6: Five search/filter options + live DOM updates.
  ['search', 'destination-filter', 'category-filter', 'budget-filter', 'duration-filter', 'difficulty-filter']
    .forEach(id => $(id).addEventListener(id === 'search' ? 'input' : 'change', () => renderCards()));

  $('clear-filters').addEventListener('click', () => {
    $('search').value = '';
    ['destination-filter', 'category-filter', 'budget-filter', 'duration-filter', 'difficulty-filter'].forEach(id => $(id).value = 'All');
    renderCards();
  });

  function refreshDestinationFilter() {
    const select = $('destination-filter');
    const current = select.value;
    const destinations = [...new Set(trips.map(trip => trip.destination))].sort();
    select.innerHTML = '<option value="All">All</option>' + destinations.map(d => `<option value="${escapeHtml(d)}">${escapeHtml(d)}</option>`).join('');
    select.value = destinations.includes(current) ? current : 'All';
  }

  function renderStats() {
    const totalBudget = trips.reduce((sum, trip) => sum + trip.budget, 0);
    const avgRating = trips.length ? trips.reduce((sum, trip) => sum + trip.rating, 0) / trips.length : 0;
    const longest = trips.length ? Math.max(...trips.map(t => t.duration)) : 0;
    $('stats').innerHTML = [
      ['Total Trips', trips.length, 'Array records'],
      ['Average Rating', avgRating.toFixed(1), 'Out of 5'],
      ['Total Budget', '$' + totalBudget, 'All records'],
      ['Longest Trip', longest + ' days', 'Duration']
    ].map(stat => `<div class="p-5 rounded-2xl bg-white/10 border border-white/10"><p class="text-sm text-slate-300">${stat[0]}</p><p class="mt-1 text-2xl font-bold">${stat[1]}</p><p class="mt-1 text-xs text-slate-400">${stat[2]}</p></div>`).join('');
  }

  // CONTROL STRUCTURES STEP 1: At least five if–else decisions.
  function classifyTrip(trip) {
    const results = [];

    // Condition 1: budget
    if (trip.budget < 800) results.push(['Budget', 'Low-cost plan']);
    else if (trip.budget <= 1500) results.push(['Budget', 'Mid-range plan']);
    else results.push(['Budget', 'Premium plan']);

    // Condition 2: duration
    if (trip.duration <= 4) results.push(['Duration', 'Short getaway']);
    else if (trip.duration <= 7) results.push(['Duration', 'Standard holiday']);
    else results.push(['Duration', 'Long adventure']);

    // Condition 3: difficulty
    if (trip.difficulty === 'Easy') results.push(['Difficulty', 'Beginner friendly']);
    else if (trip.difficulty === 'Moderate') results.push(['Difficulty', 'Some preparation needed']);
    else results.push(['Difficulty', 'Challenging']);

    // Condition 4: rating
    if (trip.rating >= 4.8) results.push(['Rating', 'Top rated']);
    else if (trip.rating >= 4.5) results.push(['Rating', 'Highly rated']);
    else results.push(['Rating', 'Good rated']);

    // Condition 5: group suitability
    if (trip.category === 'Adventure' || trip.difficulty === 'Hard') results.push(['Group fit', 'Best for active travelers']);
    else if (trip.category === 'Culture' || trip.category === 'Food') results.push(['Group fit', 'Great for social/cultural groups']);
    else results.push(['Group fit', 'Flexible for most travelers']);

    return results;
  }

  function renderControlStructures() {
    const sample = getFilteredTrips()[0] || trips[0];
    if (!sample) {
      $('condition-output').innerHTML = '<p class="text-sm text-slate-500">Add a trip to see conditions.</p>';
      return;
    }
    $('condition-output').innerHTML = classifyTrip(sample).map(item =>
      `<div class="p-3 bg-slate-50 border border-slate-200 rounded-xl"><p class="text-xs uppercase font-bold text-slate-400">${item[0]}</p><p class="mt-1 font-semibold text-slate-800">${item[1]}</p></div>`
    ).join('');

    // CONTROL STRUCTURES STEP 2: for loop displays project data as a list.
    let destinationList = '<ul class="space-y-2">';
    for (let i = 0; i < trips.length; i++) {
      destinationList += `<li class="flex justify-between p-3 bg-slate-50 rounded-lg"><span>${i + 1}. ${escapeHtml(trips[i].destination)}</span><span class="font-semibold">${trips[i].duration} days</span></li>`;
    }
    destinationList += '</ul>';
    $('for-output').innerHTML = `<h3 class="mb-2 text-sm font-bold text-slate-700">For-loop destination list</h3>${destinationList}`;

    // CONTROL STRUCTURES STEP 3: while loop processes each project record.
    let index = 0;
    let whileHtml = '<div class="p-4 border border-brand-100 bg-brand-50 rounded-xl"><h3 class="text-sm font-bold text-brand-800">While-loop processing</h3><ul class="mt-2 space-y-1 text-sm text-brand-900">';
    while (index < trips.length) {
      const trip = trips[index];
      whileHtml += `<li>Processed record ${index + 1}: ${escapeHtml(trip.name)}</li>`;
      index++;
    }
    whileHtml += '</ul></div>';
    $('while-output').innerHTML = whileHtml;

    // STEP 4: Combine loop + conditions to categorize every record.
    const groups = { 'Budget Friendly': [], 'Balanced': [], 'Premium Adventure': [] };
    for (const trip of trips) {
      if (trip.budget < 800) groups['Budget Friendly'].push(trip.name);
      else if (trip.budget <= 1500 && trip.difficulty !== 'Hard') groups.Balanced.push(trip.name);
      else groups['Premium Adventure'].push(trip.name);
    }
    $('combined-output').innerHTML = Object.entries(groups).map(([label, names]) =>
      `<div class="p-4 bg-white border border-slate-200 rounded-xl"><h4 class="font-bold">${label}</h4><p class="mt-2 text-sm text-slate-500">${names.length ? names.map(escapeHtml).join(', ') : 'No matching trips'}</p></div>`
    ).join('');
  }

  refreshDestinationFilter();
  renderCards();
})();
