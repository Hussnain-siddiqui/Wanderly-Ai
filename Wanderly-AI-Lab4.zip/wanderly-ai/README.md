# Wanderly AI: Lab 4 - JavaScript CRUD & Control Structures

Web Engineering, Assignment 01 (BSCS, The University of Lahore, Fall 2026).
Multi-page site built with HTML, CSS, Tailwind CSS and Flowbite. No build step needed.

## Folder structure

```
wanderly-ai/
├── index.html              Home
├── src/pages/
│   ├── about.html
│   ├── contact.html
│   ├── signup.html
│   └── signin.html
└── assets/
    ├── css/style.css
    ├── js/main.js          validation, Formspree, planner preview
    ├── js/tailwind-config.js
    └── images/logo.svg
```

## Before you submit

1. **Connect Formspree** (Contact page).
   Create a free form at https://formspree.io, copy its ID, then in `src/pages/contact.html` replace
   `YOUR_FORM_ID` in `action="https://formspree.io/f/YOUR_FORM_ID"`.
   Send one test message so Formspree confirms the form.
2. **Personalize the team section** in `src/pages/about.html` (names and roles are placeholders).
3. **Deploy on GitHub Pages**
   - Create a repo and push everything inside this folder (so `index.html` is at the repo root).
   - Settings > Pages > Source: "Deploy from a branch", branch `main`, folder `/ (root)`.
   - Your live link will be `https://<username>.github.io/<repo>/`. Put it at the top of the PDF report.
4. Push again after every change so the live link matches the latest code.

## Where each rubric item lives

| Requirement | Where |
|---|---|
| Responsive navbar (logo, Home/About/Contact, Sign Up/Sign In), same on all pages | top of every page |
| Footer, same on all pages | bottom of every page |
| Home: hero + 10+ components | `index.html` (each block has a `COMPONENT n` comment) |
| About: 5 components | `src/pages/about.html` (stats, timeline, team, testimonial, accordion) |
| Contact: 5+ Flowbite components, Formspree, validation | `src/pages/contact.html` + `assets/js/main.js` |
| Sign Up: 5+ Tailwind components, "Already have an account? Sign in." | `src/pages/signup.html` |
| Sign In: 5+ Flowbite components, "Don't have an account? Sign up." | `src/pages/signin.html` |

## Notes

- The home-page planner is a browser-only preview with sample logic. It is not connected to a real AI model.
- Sign Up and Sign In are front-end demos: they validate input but do not store accounts.
- Statistics, testimonials, prices and team members are placeholder content.
- Tailwind and Flowbite load from CDNs, so pages need an internet connection.


## JavaScript CRUD Lab Task

The project now includes `src/pages/trips.html`, a complete CRUD/control-structures lab implementation:

- **Array of objects:** six sample Wanderly trip records in `assets/js/crud.js`.
- **Read:** `Array.map()` dynamically renders records as responsive grid cards.
- **Create:** the form uses `Array.push()` and immediately re-renders the cards.
- **Delete:** each card uses `Array.filter()` to remove the selected record.
- **Update:** Edit opens a pre-filled modal; Update changes the selected object and re-renders.
- **Search/filter:** search plus five filters — Destination, Category, Budget, Duration and Difficulty.
- **If–Else:** five project-related decision sets (budget, duration, difficulty, rating, group fit).
- **For loop:** generates a destination list.
- **While loop:** processes every trip record and writes the result to the DOM.
- **Combined loop + conditions:** categorizes all trips into Budget Friendly, Balanced and Premium Adventure.

### Suggested screenshots for the lab report

1. Initial grid showing the six trip cards.
2. New trip form after adding a record.
3. Grid after deleting one record.
4. Edit modal open with a selected trip pre-filled.
5. Updated card after pressing Update.
6. Search results.
7. Destination filter result.
8. Category filter result.
9. Budget filter result.
10. Duration filter result.
11. Difficulty filter result.
12. If–Else output section.
13. For-loop output.
14. While-loop output.
15. Combined loops + conditions output.

Open `src/pages/trips.html` in a browser and take the screenshots at these states. The page is designed to make each required lab output visible on one screen/section.


## Lab 4 Submission

The `src/pages/trips.html` page is the Lab 4 implementation. It demonstrates CRUD operations on an array of objects, DOM manipulation, five search/filter options, if-else decision making, for loops, while loops, and combined loops with conditions.

### Run
Open `src/pages/trips.html` in a browser. Tailwind CSS is loaded from the CDN, so an internet connection is recommended.

### Required screenshots
- Initial array cards
- Add/Create result
- Delete result
- Edit modal
- Updated record
- Search result
- Destination filter
- Category filter
- Budget filter
- Duration filter
- Difficulty filter
- If-Else output
- For-loop output
- While-loop output
- Combined loop + condition output
